# Code documentation

This folder just contains a sym-link to the location where the built code documentation lives.

This is needed as all source files need to live under the source folder.
