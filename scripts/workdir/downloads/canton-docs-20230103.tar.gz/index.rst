..
     Copyright (c) 2022 Digital Asset (Switzerland) GmbH and/or its affiliates
..
    
..
     Proprietary code. All rights reserved.


.. toctree::
  :maxdepth: 2
  :caption: Canton documentation

  about


.. toctree::
  :maxdepth: 2
  :caption: Tutorials

  tutorials/demo
  tutorials/getting_started
  tutorials/use_daml_sdk
  tutorials/composability


.. toctree::
  :maxdepth: 2
  :caption: User manual

  usermanual/downloading.rst
  usermanual/installation.rst
  usermanual/upgrading.rst
  usermanual/docker.rst
  usermanual/static_conf.rst
  usermanual/persistence.rst
  usermanual/apis.rst
  usermanual/command_line.rst
  usermanual/console.rst
  usermanual/connectivity.rst
  usermanual/packagemanagement.rst
  usermanual/identity_management.rst
  usermanual/security.rst
  usermanual/domains/domains.rst
  usermanual/manage_domain_entities
  usermanual/manage_domains
  usermanual/ha.rst
  usermanual/performance.rst
  usermanual/monitoring.rst
  usermanual/example_monitoring_setup.rst
  usermanual/pruning.rst
  usermanual/troubleshooting_guide.rst
  usermanual/repairing.rst
  usermanual/versioning.rst
  usermanual/contract_keys.rst
  usermanual/FAQ.rst

.. toctree::
  :maxdepth: 2
  :caption: Architecture in-depth

  architecture/requirements/requirements.rst
  architecture/overview.rst
  architecture/domains/domains.rst
  architecture/ha.rst
  architecture/security.rst
  architecture/identity.rst
  architecture/research.rst

.. toctree::
  :maxdepth: 2
  :caption: Reference

  reference/console.rst
  reference/error_codes.rst
  reference/admin_apis.rst


