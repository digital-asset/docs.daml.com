# Setup scripts

This folder includes setup scripts that are executed on a one-off basis.

Files in this folder can reference both interface and implementation packages of `daml-finance`.
