# Extensions

This folder includes extensions of the library.

Files in this folder can reference both interface and implementation packages of `daml-finance`.
