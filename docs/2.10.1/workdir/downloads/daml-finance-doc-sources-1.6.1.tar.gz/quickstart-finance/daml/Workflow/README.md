# Workflows

This folder includes user-defined workflows which encapsulate the core business logic of the
application.

Files in this folder can reference only the interface packages of `daml-finance`.
