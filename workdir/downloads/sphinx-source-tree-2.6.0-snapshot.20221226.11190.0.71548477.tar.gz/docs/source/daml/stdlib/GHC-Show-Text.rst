.. Copyright (c) 2022 Digital Asset (Switzerland) GmbH and/or its affiliates. All rights reserved.
.. SPDX-License-Identifier: Apache-2.0

.. _module-ghc-show-text-13336:

GHC.Show.Text
=============

Functions
---------

.. _function-ghc-show-text-showsprectext-69636:

`showsPrecText <function-ghc-show-text-showsprectext-69636_>`_
  \: :ref:`Int <type-ghc-types-int-37261>` \-\> :ref:`Text <type-ghc-types-text-51952>` \-\> ShowS
