.. Copyright (c) 2024 Digital Asset (Switzerland) GmbH and/or its affiliates. All rights reserved.
.. SPDX-License-Identifier: Apache-2.0

.. _module-ghc-tuple-check-92032:

GHC.Tuple.Check
===============

Functions
---------

.. _function-ghc-tuple-check-userwrittentuple-58630:

`userWrittenTuple <function-ghc-tuple-check-userwrittentuple-58630_>`_
  \: a \-\> a
