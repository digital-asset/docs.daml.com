// Copyright (c) 2024 Digital Asset (Switzerland) GmbH and/or its affiliates.
// Proprietary code. All rights reserved.

package com.digitalasset.canton.integration.tests.security.kms

import com.digitalasset.canton.crypto.kms.KmsKeyId
import com.digitalasset.canton.integration.EnterpriseEnvironmentDefinition
import com.digitalasset.canton.integration.tests.{
  EnterpriseIntegrationTest,
  SharedEnterpriseEnvironment,
}

trait RotateWrapperKeyIntegrationTest
    extends EnterpriseIntegrationTest
    with SharedEnterpriseEnvironment
    with EncryptedCryptoPrivateStoreTestHelpers {

  override lazy val environmentDefinition: EnterpriseEnvironmentDefinition =
    EnterpriseEnvironmentDefinition.singleDomain.withSetup { env =>
      import env.*
      participant1.domains.connect_local(da)
      participant2.domains.connect_local(da)
    }

  protected val protectedNodes: Set[String] = Set("participant1")

  protected val preDefinedKey: Option[String]

  "private keys are encrypted with correct wrapper key after rotation" in { implicit env =>
    import env.*

    val encStore = getEncryptedCryptoStore(participant1.name)

    val initialKeys = listAllStoredKeys(encStore)
    val initialWrapperKey = encStore.wrapperKeyId

    preDefinedKey match {
      case Some(newWrapperKeyId) =>
        // user-manual-entry-begin: ManualWrapperKeyRotation
        participant1.keys.secret.rotate_wrapper_key(newWrapperKeyId)
      // user-manual-entry-end: ManualWrapperKeyRotation
      case None =>
        participant1.keys.secret.rotate_wrapper_key()
    }

    try {
      val currentWrapperKey = encStore.wrapperKeyId
      initialWrapperKey shouldNot be(currentWrapperKey)
      if (preDefinedKey.isDefined) preDefinedKey shouldBe Some(currentWrapperKey.unwrap)
      forAll(
        listAllStoredKeys(encStore.store)
          .map(storedKey => KmsKeyId(storedKey.wrapperKeyId.valueOrFail("no wrapper key")))
      ) { wrapperKey =>
        wrapperKey shouldBe currentWrapperKey
      }

      val decryptedKeys = checkAndDecryptKeys(participant1.name)
      // compare decrypted result with previously existent keys (e.g. before the rotation)
      decryptedKeys.map(_.copy(wrapperKeyId = None)).toSet shouldBe initialKeys
        .map(_.copy(wrapperKeyId = None))
        .toSet
    } finally {
      if (preDefinedKey.isEmpty) encStore.kms.deleteKey(encStore.wrapperKeyId).futureValue
    }
  }

}
