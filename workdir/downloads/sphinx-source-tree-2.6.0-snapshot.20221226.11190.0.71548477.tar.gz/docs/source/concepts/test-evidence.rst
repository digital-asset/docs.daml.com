.. Copyright (c) 2022 Digital Asset (Switzerland) GmbH and/or its affiliates. All rights reserved.
.. SPDX-License-Identifier: Apache-2.0

.. _test-evidence:

Test Evidence
#################

Daml is publishing test evidence for the the most important traits of tests: Security, Operability, Functional and Reliability.

It can be found in the relevant `releases <https://github.com/digital-asset/daml/releases>`_ page, under `Assets`.
