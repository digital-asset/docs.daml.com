
create database canton1db;
create database index1db;

create database domain0db;

create database canton2db;
create database index2db;


